package com.example.einkaufsliste.rest;

public class IllegalCreateException extends Exception {
}
