package com.example.einkaufsliste.rest;

public class NoSuchRowException extends Exception {
}
