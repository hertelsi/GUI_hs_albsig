package aufgabe1;
public class Aufgabe1Main {

	public static void main(String[] args) {
		
		Aufgabe1 w = Aufgabe1.createNewWindow();
		w.open();

	}

} 
